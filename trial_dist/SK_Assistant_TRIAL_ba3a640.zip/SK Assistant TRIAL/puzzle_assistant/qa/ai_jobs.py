"""Running AI requests in the background without letting old questions block
new ones (owner-approved change B).

v3.3 had ONE background lane: when a question closed before its AI answer
arrived, the old request kept the lane busy (up to its 6-8 s time limit) and
the next question waited behind it.

Now:
  * The newest question always wins: submitting a request for a question
    cancels every request for other questions. A request that has not started
    yet is removed and never sent; a running one is stopped (its connection
    is closed, so it ends at once) and its result is ignored.
  * Strict limits, so the AI quota is never wasted: at most LANES (2) requests
    run at the same time and at most ONE request waits (always the newest -
    older waiting requests are cancelled). The second lane only exists so a
    new question never waits for an old request that is still stopping.
  * Every request carries a CancelToken; the AI code checks it before each
    call to the provider (no second call, e.g. after a web search, for a
    question that is gone).
"""
from __future__ import annotations

import socket
import sys
import threading
import time
from concurrent.futures import Future, ThreadPoolExecutor
from typing import Callable, List, Optional

LANES = 2
_local = threading.local()


class CancelToken:
    def __init__(self):
        self._event = threading.Event()
        self._lock = threading.Lock()
        self._conns: list = []

    @property
    def cancelled(self) -> bool:
        return self._event.is_set()

    def attach(self, conn) -> None:
        """A connection in use for this request (closed on cancel)."""
        with self._lock:
            self._conns.append(conn)
            cancelled = self.cancelled
        if cancelled:
            _shutdown(conn)

    def detach(self, conn) -> None:
        with self._lock:
            if conn in self._conns:
                self._conns.remove(conn)

    def cancel(self) -> None:
        with self._lock:
            self._event.set()
            conns = list(self._conns)
        for c in conns:
            _shutdown(c)


# Windows: shutdown() does not wake a thread that is waiting (select) for the
# reply - found on the owner's PC (the request kept running until the server
# answered). Closing the socket does wake it there. Linux: shutdown() wakes it;
# the socket is not closed from this thread (its number could be reused at once
# by another connection while the reading thread still holds it).
CLOSE_ON_CANCEL = sys.platform == "win32"


def _shutdown(conn) -> None:
    """Make a blocked read on this connection return immediately."""
    sock = getattr(conn, "sock", None)
    if sock is None:
        return
    try:
        sock.shutdown(socket.SHUT_RDWR)
    except OSError:
        pass
    if CLOSE_ON_CANCEL:
        try:
            sock.close()
        except Exception:
            pass


def current_token() -> Optional[CancelToken]:
    """The token of the request running on this thread (None outside a job)."""
    return getattr(_local, "token", None)


class AiJob:
    def __init__(self, ident, token: CancelToken):
        self.ident = ident
        self.token = token
        self.future: Future = Future()
        self.submitted = time.monotonic()
        self.started: Optional[float] = None
        self.finished: Optional[float] = None
        self.logged = False                     # written to the timing log once
        self.meta: dict = {}                    # category / kind / timed, for the log

    @property
    def queue_ms(self) -> float:
        if self.started is None:
            return 0.0
        return (self.started - self.submitted) * 1000

    @property
    def run_ms(self) -> float:
        if self.started is None or self.finished is None:
            return 0.0
        return (self.finished - self.started) * 1000


class AiScheduler:
    """At most `lanes` running and one waiting request; the newest question wins."""

    def __init__(self, lanes: int = LANES, on_stale: Optional[Callable[[AiJob, object], None]] = None):
        self.lanes = lanes
        self._pool = ThreadPoolExecutor(max_workers=lanes, thread_name_prefix="ai")
        self._lock = threading.Lock()
        self._jobs: List[AiJob] = []
        self.on_stale = on_stale                # called once for a cancelled job

    def submit(self, ident, fn: Callable, *args) -> AiJob:
        with self._lock:
            self._jobs = [j for j in self._jobs if not j.future.done()]
            for j in self._jobs:
                if j.ident != ident:
                    self._cancel(j)
            same = [j for j in self._jobs if j.ident == ident and not j.token.cancelled]
            if same:                            # already asked: never twice
                return same[0]
            job = AiJob(ident, CancelToken())
            job.future = self._pool.submit(self._run, job, fn, args)
            self._jobs.append(job)
            return job

    def _run(self, job: AiJob, fn, args):
        job.started = time.monotonic()
        if job.token.cancelled:
            job.finished = job.started
            self._stale(job, None)
            return None
        _local.token = job.token
        result = None
        try:
            result = fn(*args)
            return result
        finally:
            _local.token = None
            job.finished = time.monotonic()
            if job.token.cancelled:
                self._stale(job, result)

    def _stale(self, job: AiJob, result) -> None:
        cb = self.on_stale
        if cb is None or job.logged:
            return
        job.logged = True
        try:
            cb(job, result)
        except Exception:
            pass

    def _cancel(self, job: AiJob) -> None:
        job.token.cancel()
        if job.future.cancel():                 # had not started: never sent
            job.started = job.finished = time.monotonic()
            self._stale(job, None)
        elif job.finished is not None:          # had just finished: result ignored
            self._stale(job, None)

    def cancel(self, job: Optional[AiJob]) -> None:
        if job is None:
            return
        with self._lock:
            self._cancel(job)

    def cancel_all(self) -> None:
        with self._lock:
            for j in self._jobs:
                if not j.future.done():
                    self._cancel(j)
            self._jobs = []

    def active(self) -> int:
        """Requests running or waiting (for tests and diagnostics)."""
        with self._lock:
            return sum(1 for j in self._jobs if not j.future.done())

    def shutdown(self) -> None:
        self.cancel_all()
        self._pool.shutdown(wait=False)
