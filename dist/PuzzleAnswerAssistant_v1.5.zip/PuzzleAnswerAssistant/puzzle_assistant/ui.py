"""Floating, always-on-top, dark answer window (Tkinter + Pillow for the
anti-aliased chips and badges).

The window only DISPLAYS information. It never sends clicks or keystrokes to
any other program.
"""
from __future__ import annotations

import queue
import sys
import tkinter as tk
from typing import Optional

from .analyzer import Analysis
from .config import Config
from .engine import Engine
from .overlay import Overlay, overlay_items

from . import render as R

BG = R.hexc(R.BG)
PANEL = R.hexc(R.SURFACE)
HOVER = R.hexc(R.SURFACE_2)
FG = R.hexc(R.TEXT)
DIM = R.hexc(R.MUTED)
ACCENT = R.hexc(R.BLUE)
GOOD = R.hexc(R.GREEN_SOFT)
WARN = R.hexc(R.AMBER)
BAD = R.hexc(R.RED)
FONT = "Segoe UI" if sys.platform == "win32" else "DejaVu Sans"
FONT_SEMI = "Segoe UI Semibold" if sys.platform == "win32" else "DejaVu Sans"


def _win32_tweaks(root: tk.Tk) -> None:
    """Dark title bar + hide this window from screen capture (so it can never
    cover/confuse the puzzle it is reading). Purely cosmetic / self-affecting."""
    if sys.platform != "win32":
        return
    import ctypes
    try:
        hwnd = ctypes.windll.user32.GetParent(root.winfo_id())
        val = ctypes.c_int(1)
        for attr in (20, 19):  # DWMWA_USE_IMMERSIVE_DARK_MODE (new / old builds)
            if ctypes.windll.dwmapi.DwmSetWindowAttribute(
                    hwnd, attr, ctypes.byref(val), ctypes.sizeof(val)) == 0:
                break
        ctypes.windll.user32.SetWindowDisplayAffinity(hwnd, 0x11)  # WDA_EXCLUDEFROMCAPTURE
    except Exception:
        pass


def _set_icon(root: tk.Tk) -> None:
    """Window / taskbar icon (assets/app.ico)."""
    import os
    base = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets")
    try:
        if sys.platform == "win32":
            root.iconbitmap(default=os.path.join(base, "app.ico"))
        else:
            root.iconphoto(True, tk.PhotoImage(file=os.path.join(base, "app.png")))
    except Exception:
        pass


class RegionSelector:
    """Full-screen translucent overlay: drag a rectangle around the puzzle."""

    def __init__(self, root: tk.Tk, on_done):
        from .capture import new_mss
        with new_mss() as sct:
            v = sct.monitors[0]
        self.left, self.top = v["left"], v["top"]
        self.on_done = on_done
        self.win = tk.Toplevel(root)
        self.win.overrideredirect(True)
        self.win.attributes("-topmost", True)
        self.win.attributes("-alpha", 0.30)
        self.win.geometry(f"{v['width']}x{v['height']}+{v['left']}+{v['top']}")
        self.cv = tk.Canvas(self.win, bg="black", highlightthickness=0, cursor="crosshair")
        self.cv.pack(fill="both", expand=True)
        self.cv.create_text(v["width"] // 2, 40, fill="white", font=(FONT, 18, "bold"),
                            text="Drag a box around the whole puzzle window  ·  Esc = cancel")
        self.start = None
        self.rect = None
        self.cv.bind("<ButtonPress-1>", self._press)
        self.cv.bind("<B1-Motion>", self._drag)
        self.cv.bind("<ButtonRelease-1>", self._release)
        self.win.bind("<Escape>", lambda e: self._finish(None))
        self.win.focus_force()

    def _press(self, e):
        self.start = (e.x, e.y)
        self.rect = self.cv.create_rectangle(e.x, e.y, e.x, e.y, outline="#5aa9ff", width=3)

    def _drag(self, e):
        if self.start:
            self.cv.coords(self.rect, self.start[0], self.start[1], e.x, e.y)

    def _release(self, e):
        if not self.start:
            return
        x0, y0 = self.start
        x, y, w, h = min(x0, e.x), min(y0, e.y), abs(e.x - x0), abs(e.y - y0)
        self._finish([x + self.left, y + self.top, w, h] if w > 40 and h > 40 else None)

    def _finish(self, region):
        self.win.destroy()
        self.on_done(region)


class App:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.q: "queue.Queue[dict]" = queue.Queue()
        self.engine = Engine(cfg, self.q)
        self._images = {}                 # keep PhotoImage references alive
        self._view: Optional[dict] = None  # last rendered state (for resizes)

        r = self.root = tk.Tk()
        r.title("Puzzle Answer Assistant")
        r.configure(bg=BG)
        r.geometry(cfg.window_geometry)
        r.minsize(300, 220)
        _set_icon(r)
        r.attributes("-topmost", True)
        try:
            r.attributes("-alpha", float(cfg.opacity))
        except tk.TclError:
            pass
        r.columnconfigure(0, weight=1)

        # ---- header: icon, title, status pill --------------------------------
        head = tk.Frame(r, bg=BG)
        head.grid(row=0, column=0, sticky="we", padx=14, pady=(12, 0))
        head.columnconfigure(1, weight=1)
        self.l_icon = tk.Label(head, bg=BG)
        self.l_icon.grid(row=0, column=0, padx=(0, 8))
        self._set_image(self.l_icon, "icon", _app_icon(18))
        tk.Label(head, text="Puzzle Assistant", bg=BG, fg=FG, font=(FONT_SEMI, 11),
                 anchor="w").grid(row=0, column=1, sticky="w")
        self.l_pill = tk.Label(head, bg=BG)
        self.l_pill.grid(row=0, column=2, sticky="e")
        self.l_target = tk.Label(r, text="", bg=BG, fg=DIM, font=(FONT, 10), anchor="w")
        self.l_target.grid(row=1, column=0, sticky="we", padx=14, pady=(4, 6))

        # ---- main card -------------------------------------------------------
        card = self.card = tk.Frame(r, bg=PANEL, highlightthickness=1,
                                    highlightbackground=R.hexc(R.BORDER))
        card.grid(row=2, column=0, sticky="nswe", padx=12)
        r.rowconfigure(2, weight=1)
        card.columnconfigure(0, weight=1)
        self.l_section = tk.Label(card, text="", bg=PANEL, fg=DIM, font=(FONT_SEMI, 8), anchor="w")
        self.l_section.grid(row=0, column=0, sticky="we", padx=12, pady=(10, 4))
        self.l_main = tk.Label(card, bg=PANEL, fg=DIM, font=(FONT_SEMI, 20), anchor="w",
                               justify="left")
        self.l_main.grid(row=1, column=0, sticky="we", padx=12)
        self.l_next = tk.Label(card, text="", bg=PANEL, fg=FG, font=(FONT, 10), anchor="w",
                               justify="left")
        self.l_next.grid(row=2, column=0, sticky="we", padx=12, pady=(8, 0))
        tagrow = tk.Frame(card, bg=PANEL)
        tagrow.grid(row=3, column=0, sticky="we", padx=12, pady=(6, 0))
        self.l_tag_title = tk.Label(tagrow, text="", bg=PANEL, fg=DIM, font=(FONT, 9))
        self.l_tag_title.pack(side="left")
        self.l_tags = tk.Label(tagrow, bg=PANEL)
        self.l_tags.pack(side="left", padx=(6, 0))
        self.l_hint = tk.Label(card, text="", bg=PANEL, fg=DIM, font=(FONT, 9), anchor="w",
                               justify="left")
        self.l_hint.grid(row=4, column=0, sticky="we", padx=12, pady=(4, 10))

        self.l_warn = tk.Label(r, text="", bg=BG, fg=WARN, font=(FONT, 9), anchor="w",
                               justify="left")
        self.l_warn.grid(row=3, column=0, sticky="we", padx=14, pady=(6, 0))

        # ---- toolbar ---------------------------------------------------------
        bar = tk.Frame(r, bg=BG)
        bar.grid(row=4, column=0, sticky="we", padx=10, pady=(6, 10))
        bar.columnconfigure(9, weight=1)
        self.b_overlay = None
        for i, (txt, cmd) in enumerate((("Rescan", self.engine.rescan),
                                        ("Numbers", self.toggle_overlay),
                                        ("Region", self.pick_region),
                                        ("Auto", self.clear_region),
                                        ("Snapshot", self.engine.snapshot))):
            b = _flat_button(bar, txt, cmd)
            b.grid(row=0, column=i, padx=(0, 4))
            if txt == "Numbers":
                self.b_overlay = b
        self.l_mode = tk.Label(bar, text="", bg=BG, fg=DIM, font=(FONT, 8))
        self.l_mode.grid(row=0, column=10, sticky="e")

        r.bind("<F5>", lambda e: self.engine.rescan())
        r.bind("<F8>", lambda e: self.engine.snapshot())
        r.bind("<Configure>", self._on_resize)
        r.protocol("WM_DELETE_WINDOW", self.close)
        r.after(50, lambda: _win32_tweaks(r))
        self._last_w = 0
        self._resize_job = None
        self._last_analysis: Optional[Analysis] = None
        self._last_place: Optional[dict] = None
        # Step numbers drawn on the cards (click-through, hidden from capture)
        self.overlay = Overlay(r)
        self.engine.overlay_in_capture = self.overlay.available and not self.overlay.hidden_from_capture
        if not self.overlay.available:
            self.b_overlay.grid_remove()       # needs Windows
        self._update_overlay_button()
        self._update_region_label()
        self._waiting("Starting…")

    # -- small helpers ---------------------------------------------------------
    def _set_image(self, label: tk.Label, key: str, pil_img) -> None:
        from PIL import ImageTk
        if pil_img is None:
            label.config(image="")
            self._images.pop(key, None)
            return
        photo = ImageTk.PhotoImage(pil_img)
        self._images[key] = photo
        label.config(image=photo)

    def _pill(self, text: str, colour) -> None:
        self._set_image(self.l_pill, "pill", R.status_pill(text, colour, 22, R.BG))

    def _content_width(self) -> int:
        return max(200, self.root.winfo_width() - 2 * 12 - 2 * 12 - 2)

    # -- actions -------------------------------------------------------------
    def toggle_overlay(self) -> None:
        self.cfg.overlay = not self.cfg.overlay
        self.cfg.save()
        self._update_overlay_button()
        self._draw_overlay()

    def _update_overlay_button(self) -> None:
        if self.b_overlay is not None:
            self.b_overlay.config(text="Numbers: on" if self.cfg.overlay else "Numbers: off")

    def _draw_overlay(self) -> None:
        p, a = self._last_place, self._last_analysis
        if not self.cfg.overlay or p is None or a is None:
            self.overlay.clear()
            return
        self.overlay.show(overlay_items(a, p["cards"]))

    def pick_region(self) -> None:
        self.engine.set_paused(True)
        self.overlay.clear()
        self.root.withdraw()

        def done(region):
            self.root.deiconify()
            self.root.attributes("-topmost", True)
            if region:
                self.cfg.region = region
                self.cfg.save()
                self.engine.region_changed.set()
            self._update_region_label()
            self.engine.set_paused(False)
            self.engine.rescan()

        self.root.after(150, lambda: RegionSelector(self.root, done))

    def clear_region(self) -> None:
        self.cfg.region = None
        self.cfg.save()
        self.engine.region_changed.set()
        self._update_region_label()
        self.engine.rescan()

    def _update_region_label(self) -> None:
        self.l_mode.config(text="region" if self.cfg.region else "read-only")

    def _on_resize(self, event) -> None:
        if event.widget is not self.root:
            return
        w = event.width
        if abs(w - self._last_w) < 4:
            return
        self._last_w = w
        for lbl in (self.l_next, self.l_hint, self.l_warn, self.l_main):
            lbl.config(wraplength=max(150, w - 60))
        if self._resize_job:
            self.root.after_cancel(self._resize_job)
        self._resize_job = self.root.after(60, self._rerender)

    def _rerender(self) -> None:
        self._resize_job = None
        if self._view and self._view.get("analysis") is not None:
            self._render(self._view["analysis"])

    # -- engine messages -----------------------------------------------------
    def _poll(self) -> None:
        latest = None
        try:
            while True:
                latest = self.q.get_nowait()
                if latest.get("state") == "info":
                    self.l_hint.config(text=latest.get("msg", ""), fg=ACCENT)
                    latest = None
                elif latest.get("state") == "overlay_clear":
                    self._last_place = None
                    self.overlay.clear()
                    latest = None
        except queue.Empty:
            pass
        if latest:
            self._show(latest)
        self.root.after(25, self._poll)

    def _show(self, m: dict) -> None:
        st = m.get("state")
        if st in ("waiting", "searching", "analyzing"):
            self._last_place = self._last_analysis = None
            self.overlay.clear()
            if st == "waiting":
                self._waiting(m.get("msg", "Waiting for puzzle…"))
            else:
                self._pill("Reading…", R.BLUE)
            return
        if st == "error":
            self._pill("Error", R.RED)
            self.l_warn.config(text=m.get("msg", ""), fg=BAD)
            return
        a: Optional[Analysis] = m.get("analysis")
        if a is None:
            return
        self._render(a)
        self._last_analysis, self._last_place = a, m.get("place")
        self._draw_overlay()

    def _waiting(self, msg: str) -> None:
        self._view = None
        self._pill("Waiting", R.MUTED)
        self.l_target.config(text="Open the weapon puzzle in the game")
        self.l_section.config(text="")
        self._set_image(self.l_main, "main", None)
        self.l_main.config(text="Waiting for puzzle…" if "No puzzle" not in msg else msg,
                           fg=DIM, font=(FONT_SEMI, 18))
        self.l_next.config(text="")
        self.l_tag_title.config(text="")
        self._set_image(self.l_tags, "tags", None)
        self.l_hint.config(text="The numbers appear on the cards as soon as it opens.", fg=DIM)
        err = getattr(getattr(self, "overlay", None), "error", "")
        self.l_warn.config(text=f"Numbers on cards unavailable: {err}" if err else "", fg=WARN)

    def _render(self, a: Analysis) -> None:
        self._view = {"analysis": a}
        s, p = a.solution, a.puzzle
        width = self._content_width()
        if s is None or p is None:
            self._pill("No answer", R.RED)
            self.l_section.config(text="")
            self._set_image(self.l_main, "main", None)
            self.l_main.config(text="Can't read this puzzle", fg=BAD, font=(FONT_SEMI, 16))
            self.l_next.config(text=a.error)
            self.l_hint.config(text="Press F5 to read again", fg=DIM)
            return
        target = p.target_caliber or "?"
        self.l_target.config(text=f"{p.weapon or 'Arma'}  ·  calibre {target}")
        dont = [(l, p.pieces[l].caliber or "") for l in s.excluded]

        if s.ok and s.certain:
            self._pill("Verified", R.GREEN_SOFT)
            self.l_warn.config(text="")
            if s.remaining:
                nums = dict(s.numbering) or {l: i + 1 for i, l in enumerate(s.order)}
                nxt = s.remaining[0]
                steps = [(l, nums.get(l, i + 1),
                          "done" if l in s.done else ("next" if l == nxt else "step"),
                          p.pieces[l].name) for i, l in enumerate(s.order)]
                self.l_section.config(text=f"ORDER  ·  {len(s.done)}/{len(s.order)} DONE"
                                      if s.done else "ORDER")
                self.l_main.config(text="")
                self._set_image(self.l_main, "main", R.chips(steps, width, R.SURFACE))
                name = p.pieces[nxt].name
                self.l_next.config(text=f"Next:  {nxt}" + (f"  ·  {name}" if name else ""), fg=FG)
                self.l_hint.config(text="Then press PROBAR. Pieces turn ✓ as you mount them.",
                                   fg=DIM)
            else:
                self.l_section.config(text="ALL PIECES MOUNTED")
                self.l_main.config(text="")
                self._set_image(self.l_main, "main", R.pill("PROBAR", 40))
                self.l_next.config(text="Press Probar to test the weapon.", fg=FG)
                self.l_hint.config(text="")
            self._tags(dont, width)
            return

        # Not verified: never show an order that looks clickable. A click on a
        # piece that is not ready costs a point.
        check = ", ".join(s.doubtful)
        self._set_image(self.l_main, "main", None)
        self._tags([], width)
        if s.ok:
            self._pill("Not sure", R.AMBER)
            self.l_section.config(text="DON'T FOLLOW YET")
            self.l_main.config(text=f"Check card {check}" if check else "Reading unclear",
                               fg=WARN, font=(FONT_SEMI, 18))
            guess = " → ".join(s.remaining)
            self.l_next.config(text=f"Unverified guess:  {guess}" if guess else "", fg=DIM)
        else:
            self._pill("No answer", R.RED)
            self.l_section.config(text="NOT RELIABLE")
            self.l_main.config(text=f"Check card {check}" if check else "Can't solve this reading",
                               fg=BAD, font=(FONT_SEMI, 18))
            self.l_next.config(text="")
        self.l_hint.config(text="Press F5 to read again.", fg=DIM)
        msgs = [f"✖  {x}" for x in s.problems] + [f"⚠  {x}" for x in s.warnings]
        self.l_warn.config(text="\n".join(msgs[:4]) + ("\n…" if len(msgs) > 4 else ""),
                           fg=BAD if s.problems else WARN)

    def _tags(self, items, width: int) -> None:
        img = R.tags(items, 22, R.RED, R.SURFACE) if items else None
        self.l_tag_title.config(text="Don't click" if items else "")
        self._set_image(self.l_tags, "tags", img)

    # -- lifecycle -------------------------------------------------------------
    def run(self) -> None:
        self.engine.start()
        self.root.after(25, self._poll)
        self.root.mainloop()

    def close(self) -> None:
        try:
            self.cfg.window_geometry = self.root.geometry()
            self.cfg.save()
        finally:
            self.engine.stop()
            self.root.destroy()


def _flat_button(parent, text: str, cmd) -> tk.Label:
    """Flat, rounded-looking text button with hover highlight."""
    b = tk.Label(parent, text=text, bg=PANEL, fg=DIM, font=(FONT, 9), padx=10, pady=4,
                 cursor="hand2")
    b.bind("<Button-1>", lambda e: cmd())
    b.bind("<Enter>", lambda e: b.config(bg=HOVER, fg=FG))
    b.bind("<Leave>", lambda e: b.config(bg=PANEL, fg=DIM))
    return b


def _app_icon(size: int):
    import os
    from PIL import Image
    path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "assets", "app.png")
    try:
        return Image.open(path).convert("RGBA").resize((size, size), Image.LANCZOS)
    except Exception:
        return None
