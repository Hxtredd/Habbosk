"""Floating, always-on-top, dark answer window (Tkinter + Pillow for the
anti-aliased chips and badges).

The window only DISPLAYS information. It never sends clicks or keystrokes to
any other program.
"""
from __future__ import annotations

import queue
import threading
import sys
import tkinter as tk
import tkinter.font as tkfont
from typing import Optional

from .analyzer import Analysis
from .config import Config
from .engine import Engine
from .overlay import Overlay, money_overlay_items, overlay_items, question_overlay_items
from .ocr import Tesseract
from .qa.ai import AIAnswerer
from .qa.memory import Memory
from .settings_ui import open_settings
from .storage import add_seed, migrate_legacy, repair_math_reads

from . import render as R

BG = R.hexc(R.BG)
PANEL = R.hexc(R.SURFACE)
HOVER = R.hexc(R.SURFACE_2)
FG = R.hexc(R.TEXT)
DIM = R.hexc(R.MUTED)
ACCENT = R.hexc(R.BLUE)
GOOD = R.hexc(R.GREEN_SOFT)
WARN = R.hexc(R.AMBER)
BAD = R.hexc(R.RED)
FONT = "Segoe UI" if sys.platform == "win32" else "DejaVu Sans"
FONT_SEMI = "Segoe UI Semibold" if sys.platform == "win32" else "DejaVu Sans"


def _win32_tweaks(root: tk.Tk) -> None:
    """Dark title bar + hide this window from screen capture (so it can never
    cover/confuse the puzzle it is reading). Purely cosmetic / self-affecting."""
    if sys.platform != "win32":
        return
    import ctypes
    try:
        hwnd = ctypes.windll.user32.GetParent(root.winfo_id())
        val = ctypes.c_int(1)
        for attr in (20, 19):  # DWMWA_USE_IMMERSIVE_DARK_MODE (new / old builds)
            if ctypes.windll.dwmapi.DwmSetWindowAttribute(
                    hwnd, attr, ctypes.byref(val), ctypes.sizeof(val)) == 0:
                break
        ctypes.windll.user32.SetWindowDisplayAffinity(hwnd, 0x11)  # WDA_EXCLUDEFROMCAPTURE
    except Exception:
        pass


def _set_icon(root: tk.Tk) -> None:
    """Window / taskbar icon (assets/app.ico)."""
    import os
    base = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets")
    try:
        if sys.platform == "win32":
            root.iconbitmap(default=os.path.join(base, "app.ico"))
        else:
            root.iconphoto(True, tk.PhotoImage(file=os.path.join(base, "app.png")))
    except Exception:
        pass


class RegionSelector:
    """Full-screen translucent overlay: drag a rectangle around the puzzle."""

    def __init__(self, root: tk.Tk, on_done):
        from .capture import new_mss
        with new_mss() as sct:
            v = sct.monitors[0]
        self.left, self.top = v["left"], v["top"]
        self.on_done = on_done
        self.win = tk.Toplevel(root)
        self.win.overrideredirect(True)
        self.win.attributes("-topmost", True)
        self.win.attributes("-alpha", 0.30)
        self.win.geometry(f"{v['width']}x{v['height']}+{v['left']}+{v['top']}")
        self.cv = tk.Canvas(self.win, bg="black", highlightthickness=0, cursor="crosshair")
        self.cv.pack(fill="both", expand=True)
        self.cv.create_text(v["width"] // 2, 40, fill="white", font=(FONT, 18, "bold"),
                            text="Drag a box around the whole puzzle window  ·  Esc = cancel")
        self.start = None
        self.rect = None
        self.cv.bind("<ButtonPress-1>", self._press)
        self.cv.bind("<B1-Motion>", self._drag)
        self.cv.bind("<ButtonRelease-1>", self._release)
        self.win.bind("<Escape>", lambda e: self._finish(None))
        self.win.focus_force()

    def _press(self, e):
        self.start = (e.x, e.y)
        self.rect = self.cv.create_rectangle(e.x, e.y, e.x, e.y, outline="#5aa9ff", width=3)

    def _drag(self, e):
        if self.start:
            self.cv.coords(self.rect, self.start[0], self.start[1], e.x, e.y)

    def _release(self, e):
        if not self.start:
            return
        x0, y0 = self.start
        x, y, w, h = min(x0, e.x), min(y0, e.y), abs(e.x - x0), abs(e.y - y0)
        self._finish([x + self.left, y + self.top, w, h] if w > 40 and h > 40 else None)

    def _finish(self, region):
        self.win.destroy()
        self.on_done(region)


class App:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.q: "queue.Queue[dict]" = queue.Queue()
        self.engine = Engine(cfg, self.q)
        self._images = {}                 # keep PhotoImage references alive
        self._view: Optional[dict] = None  # last rendered state (for resizes)

        self.memory = Memory()             # learned questions (SQLite, in %APPDATA%)
        self._startup_notes = []
        try:                               # older versions kept it in the program folder
            self._startup_notes = migrate_legacy(self.memory)
            fixed = repair_math_reads(self.memory)
            if fixed:
                self._startup_notes.append(f"{fixed} sum questions will be re-learned "
                                           "(their numbers had been misread)")
            added = add_seed(self.memory)
            if added:
                self._startup_notes.append(f"{added} starter questions added")
        except Exception as exc:
            self._startup_notes.append(f"could not import old memory: {exc}")
        self.engine.memory = self.memory
        self.engine.ai = AIAnswerer(self.cfg, self.memory)
        self._settings = None
        self._update_found = None          # a newer version found at start
        # World Atlas (read-only Live Explorer), separate from the puzzles
        self.atlas = self.explorer = None
        try:
            from .world_atlas.db import Atlas
            from .world_atlas.explorer import ExplorerThread
            self.atlas = Atlas()
            done = self.atlas.import_input()
            if done:
                self._startup_notes.append(f"World Atlas: {done['rooms']} rooms imported")
            self.engine.ai.atlas = self.atlas    # the AI can use map / room knowledge
            self.atlas_q: "queue.Queue[dict]" = queue.Queue()
            self.explorer = ExplorerThread(self.atlas, lambda: Tesseract(self.cfg), self.cfg,
                                           self.atlas_q)
            self.explorer.engine_busy = lambda: self.engine.busy
        except Exception as exc:
            self._startup_notes.append(f"World Atlas unavailable: {exc}")
        r = self.root = tk.Tk()
        r.title("SK Assistant")
        self._fonts: dict = {}             # (family, base size) -> named font
        r.configure(bg=BG)
        r.geometry(cfg.window_geometry)
        r.minsize(300, 220)
        _set_icon(r)
        r.attributes("-topmost", bool(cfg.always_on_top))
        try:
            r.attributes("-alpha", float(cfg.opacity))
        except tk.TclError:
            pass
        r.columnconfigure(0, weight=1)

        r.rowconfigure(1, weight=1)
        # tab bar (Assistant | Explorer) + where the Explorer is shown
        self._build_tabbar()
        self.body = tk.Frame(r, bg=BG)
        self.body.grid(row=1, column=0, sticky="nswe")
        self.body.columnconfigure(0, weight=1)
        self.body.rowconfigure(0, weight=1)
        from .scrollframe import ScrollFrame
        self._main_scroll = ScrollFrame(self.body, BG)
        self.main_box = self._main_scroll.outer      # placed in the window / dock
        m = self.main = self._main_scroll.inner      # the assistant's content
        m.columnconfigure(0, weight=1)

        # ---- header: icon, title, status pill --------------------------------
        head = tk.Frame(m, bg=BG)
        head.grid(row=0, column=0, sticky="we", padx=14, pady=(12, 0))
        head.columnconfigure(1, weight=1)
        self.l_icon = tk.Label(head, bg=BG)
        self.l_icon.grid(row=0, column=0, padx=(0, 8))
        self._set_image(self.l_icon, "icon", _app_icon(18))
        tk.Label(head, text="SK Assistant", bg=BG, fg=FG, font=self._font(FONT_SEMI, 11),
                 anchor="w").grid(row=0, column=1, sticky="w")
        self.l_pill = tk.Label(head, bg=BG)
        self.l_pill.grid(row=0, column=2, sticky="e")
        self.l_target = tk.Label(m, text="", bg=BG, fg=DIM, font=self._font(FONT, 10), anchor="w")
        self.l_target.grid(row=1, column=0, sticky="we", padx=14, pady=(4, 6))

        # ---- main card -------------------------------------------------------
        card = self.card = tk.Frame(m, bg=PANEL, highlightthickness=1,
                                    highlightbackground=R.hexc(R.BORDER))
        card.grid(row=2, column=0, sticky="nswe", padx=12)
        m.rowconfigure(2, weight=1)
        card.columnconfigure(0, weight=1)
        self.l_section = tk.Label(card, text="", bg=PANEL, fg=DIM, font=self._font(FONT_SEMI, 8), anchor="w")
        self.l_section.grid(row=0, column=0, sticky="we", padx=12, pady=(10, 4))
        self.l_main = tk.Label(card, bg=PANEL, fg=DIM, font=self._font(FONT_SEMI, 20), anchor="w",
                               justify="left")
        self.l_main.grid(row=1, column=0, sticky="we", padx=12)
        self.l_next = tk.Label(card, text="", bg=PANEL, fg=FG, font=self._font(FONT, 10), anchor="w",
                               justify="left")
        self.l_next.grid(row=2, column=0, sticky="we", padx=12, pady=(8, 0))
        tagrow = tk.Frame(card, bg=PANEL)
        tagrow.grid(row=3, column=0, sticky="we", padx=12, pady=(6, 0))
        self.l_tag_title = tk.Label(tagrow, text="", bg=PANEL, fg=DIM, font=self._font(FONT, 9))
        self.l_tag_title.pack(side="left")
        self.l_tags = tk.Label(tagrow, bg=PANEL)
        self.l_tags.pack(side="left", padx=(6, 0))
        self.l_hint = tk.Label(card, text="", bg=PANEL, fg=DIM, font=self._font(FONT, 9), anchor="w",
                               justify="left")
        self.l_hint.grid(row=4, column=0, sticky="we", padx=12, pady=(4, 10))

        self.l_warn = tk.Label(m, text="", bg=BG, fg=WARN, font=self._font(FONT, 9), anchor="w",
                               justify="left")
        self.l_warn.grid(row=3, column=0, sticky="we", padx=14, pady=(6, 0))

        # ---- toolbar ---------------------------------------------------------
        bar = tk.Frame(m, bg=BG)
        bar.grid(row=4, column=0, sticky="we", padx=10, pady=(6, 10))
        bar.columnconfigure(9, weight=1)
        self.b_overlay = None
        buttons = {}
        for i, (txt, cmd) in enumerate((("On", self.toggle_power),
                                        ("Rescan", self.engine.rescan),
                                        ("Numbers", self.toggle_overlay),
                                        ("Settings", self.open_settings))):
            b = _flat_button(bar, txt, cmd, self._font(FONT, 9))
            b.grid(row=0, column=i, padx=(0, 4))
            buttons[txt] = b
        self.b_overlay, self.b_power = buttons["Numbers"], buttons["On"]
        self.l_mode = tk.Label(bar, text="", bg=BG, fg=DIM, font=self._font(FONT, 8))
        self.l_mode.grid(row=0, column=10, sticky="e")

        r.bind("<F5>", lambda e: self.engine.rescan())
        r.bind("<F8>", lambda e: self.engine.snapshot())
        self.main.bind("<Configure>", self._on_resize)
        r.protocol("WM_DELETE_WINDOW", self.close)
        r.after(50, lambda: _win32_tweaks(r))
        self._last_w = 0
        self._resize_job = None
        self._last_analysis: Optional[Analysis] = None
        self._last_place: Optional[dict] = None
        self._last_money = None
        self._last_question = None
        # Step numbers drawn on the cards (click-through, hidden from capture)
        self.overlay = Overlay(r)
        self.engine.overlay_in_capture = self.overlay.available and not self.overlay.hidden_from_capture
        if not self.overlay.available:
            self.b_overlay.grid_remove()       # needs Windows
        self._update_overlay_button()
        self._update_region_label()
        self._update_power()
        self._waiting("Starting…")

    # -- small helpers ---------------------------------------------------------
    def _set_image(self, label: tk.Label, key: str, pil_img) -> None:
        from PIL import ImageTk
        if pil_img is None:
            label.config(image="")
            self._images.pop(key, None)
            return
        photo = ImageTk.PhotoImage(pil_img)
        self._images[key] = photo
        label.config(image=photo)

    def _pill(self, text: str, colour) -> None:
        self._set_image(self.l_pill, "pill", R.status_pill(text, colour, round(22 * self._scale()), R.BG))

    def _content_width(self) -> int:
        return max(200, self.main.winfo_width() - 2 * 12 - 2 * 12 - 2)

    # -- actions -------------------------------------------------------------
    def toggle_power(self) -> None:
        self.cfg.assistant_on = not self.cfg.assistant_on
        self.cfg.save()
        self._setting_changed("assistant_on")

    def _update_power(self) -> None:
        on = self.cfg.assistant_on
        self.b_power.config(text="● On" if on else "○ Off", fg=GOOD if on else DIM)
        self.engine.set_paused(not on)
        if getattr(self, "explorer", None) is not None:
            (self.explorer.paused.clear if on else self.explorer.paused.set)()
        if not on:
            self._last_place = self._last_analysis = self._last_money = None
            self.overlay.clear()
            self._view = None
            self._pill("Off", R.MUTED)
            self.l_target.config(text="SK Assistant is switched off")
            self.l_section.config(text="")
            self._set_image(self.l_main, "main", None)
            self.l_main.config(text="Paused", fg=DIM, font=self._font(FONT_SEMI, 18))
            self.l_next.config(text="")
            self.l_tag_title.config(text="")
            self._set_image(self.l_tags, "tags", None)
            self.l_hint.config(text="Press “○ Off” to switch it back on.", fg=DIM)
            self.l_warn.config(text="")
        else:
            self._waiting("Waiting for puzzle…")

    # -- Assistant / Explorer: open or closed; tabs, docked, or separate --------
    DOCKS = [("tab", "One at a time (tabs)"), ("right", "Side by side: Explorer right"),
             ("left", "Side by side: Explorer left"), ("top", "Explorer on top"),
             ("bottom", "Explorer below"), ("window", "Explorer in a separate window")]

    def _build_tabbar(self) -> None:
        bar = self.tabbar = tk.Frame(self.root, bg=BG)
        bar.grid(row=0, column=0, sticky="we", padx=10, pady=(6, 0))
        self._tab = "assistant"
        self._tabs = {}
        for key, text in (("assistant", "Assistant"), ("explorer", "Explorer")):
            f = tk.Frame(bar, bg=BG)
            f.pack(side="left", padx=(0, 2))
            lbl = tk.Label(f, text=text, bg=BG, fg=DIM, font=self._font(FONT_SEMI, 9), padx=8,
                           pady=3, cursor="hand2")
            lbl.pack(side="left")
            x = tk.Label(f, text="×", bg=BG, fg=DIM, font=self._font(FONT, 10), padx=4,
                         cursor="hand2")
            x.pack(side="left")
            for w in (f, lbl):
                w.bind("<Button-1>", lambda e, k=key: self.tab_clicked(k))
            x.bind("<Button-1>", lambda e, k=key: self.close_part(k))
            self._tabs[key] = (f, lbl, x)
        self.t_assist, self.t_explore = self._tabs["assistant"][1], self._tabs["explorer"][1]
        self.t_dock = tk.Menubutton(bar, text="⧉", bg=BG, fg=DIM, activebackground=HOVER,
                                    activeforeground=FG, relief="flat", font=self._font(FONT, 10),
                                    cursor="hand2")
        menu = tk.Menu(self.t_dock, tearoff=False, bg=PANEL, fg=FG, activebackground=HOVER)
        for key, label in self.DOCKS:
            menu.add_command(label=label, command=lambda k=key: self.set_dock(k))
        self.t_dock.config(menu=menu)
        self.t_dock.pack(side="right")
        self._ex_panel = self._ex_top = self._ex_paned = None
        self._base_geom = self.cfg.window_geometry       # size of the assistant alone

    # what is open
    def _open(self, key: str) -> bool:
        if key == "explorer" and self.atlas is None:
            return False
        return bool(self.cfg.show_assistant if key == "assistant" else self.cfg.show_explorer)

    def tab_clicked(self, key: str) -> None:
        """Click on a tab: open it if closed; in tab mode, show it."""
        if not self._open(key):
            self._set_open(key, True)
        self._tab = key
        self._layout()

    def close_part(self, key: str) -> None:
        other = "explorer" if key == "assistant" else "assistant"
        if not self._open(other):
            return                                   # one part always stays open
        self._set_open(key, False)
        self._tab = other
        self._layout()

    def _set_open(self, key: str, on: bool) -> None:
        if key == "assistant":
            self.cfg.show_assistant = on
        else:
            self.cfg.show_explorer = on
        self.cfg.save()

    def open_explorer(self) -> None:
        self.tab_clicked("explorer")

    def show_tab(self, tab: str) -> None:
        self.tab_clicked(tab)

    def set_dock(self, mode: str) -> None:
        self._save_explorer_geometry()
        self.cfg.explorer_dock = mode
        if mode != "tab":                            # side by side etc.: show both
            self.cfg.show_assistant = self.cfg.show_explorer = True
        self.cfg.save()
        self._layout()

    def _style_tabs(self) -> None:
        both = self._open("assistant") and self._open("explorer")
        tabbed = self.cfg.explorer_dock == "tab"
        for key, (f, lbl, x) in self._tabs.items():
            is_open = self._open(key)
            shown = is_open and (not (both and tabbed) or key == self._tab)
            bg = PANEL if shown else BG
            for w in (f, lbl, x):
                w.config(bg=bg)
            name = "Assistant" if key == "assistant" else "Explorer"
            if key == "explorer" and self.atlas is not None and is_open:
                n = self.atlas.stats()["pending"]
                name += f" ● {n}" if n else ""
            lbl.config(text=name if is_open else f"+ {name}",
                       fg=(WARN if key == "explorer" and "●" in name else FG if shown else DIM))
            # the × only where closing leaves something open
            other = "explorer" if key == "assistant" else "assistant"
            if is_open and self._open(other):
                x.pack(side="left")
            else:
                x.pack_forget()

    def _save_explorer_geometry(self) -> None:
        try:
            if self._ex_top is not None and self._ex_top.winfo_exists():
                self.cfg.explorer_geometry = self._ex_top.geometry()
            if self._ex_paned is not None and self._ex_panel is not None:
                w = self._ex_panel.win
                side = self.cfg.explorer_dock
                size = w.winfo_width() if side in ("left", "right") else w.winfo_height()
                if size > 50:
                    self.cfg.explorer_size = int(size)
            # the assistant alone was on screen: its size is the one to remember
            if (getattr(self, "_laid_out", False) and self.root.winfo_ismapped()
                    and getattr(self, "_last_vis", None) == ("assistant",)):
                g = self.root.geometry()
                if int(g.split("x")[0]) > 100:       # a real size, not "1x1" before drawing
                    self._base_geom = g
        except tk.TclError:
            pass

    def _visible(self) -> tuple:
        """Which parts are shown inside the main window right now."""
        a, e = self._open("assistant"), self._open("explorer")
        mode = self.cfg.explorer_dock
        if a and e:
            if mode == "tab":
                return (self._tab,)
            if mode == "window":
                return ("assistant",)
            return ("assistant", "explorer")
        return ("assistant",) if a else ("explorer",)

    def _layout(self) -> None:
        """(Re)build the window for what is open and the chosen arrangement."""
        from .world_atlas.window import ExplorerPanel, hide_from_capture
        before = getattr(self, "_last_vis", None)
        self._save_explorer_geometry()
        if self._ex_panel is not None:
            self._ex_panel.win.destroy()
            self._ex_panel = None
        if self._ex_top is not None:
            self._ex_top.destroy()
            self._ex_top = None
        if self._ex_paned is not None:
            self._ex_paned.forget(self.main_box)
            self._ex_paned.destroy()
            self._ex_paned = None
        self.main_box.grid_remove()
        vis = self._visible()
        mode = self.cfg.explorer_dock
        bw, bh = (int(v) for v in self._base_geom.split("+")[0].split("x"))
        if vis == ("assistant",):
            self.main_box.grid(row=0, column=0, sticky="nswe")
            size = (bw, bh)
        elif vis == ("explorer",):
            self._ex_panel = ExplorerPanel(self.body, self.atlas, self.explorer, self._ui_font)
            self._ex_panel.win.grid(row=0, column=0, sticky="nswe")
            size = (max(bw, 580), max(bh, 640))
        else:
            horizontal = mode in ("left", "right")
            ex = max(260, int(self.cfg.explorer_size))
            pw = self._ex_paned = tk.PanedWindow(
                self.body, orient="horizontal" if horizontal else "vertical",
                bg=R.hexc(R.BORDER), sashwidth=6, bd=0, sashrelief="flat")
            pw.grid(row=0, column=0, sticky="nswe")
            self._ex_panel = ExplorerPanel(pw, self.atlas, self.explorer, self._ui_font)
            panes = [self._ex_panel.win, self.main_box] if mode in ("left", "top") else \
                [self.main_box, self._ex_panel.win]
            for p_ in panes:
                pw.add(p_, stretch="always", minsize=160)
            self.main_box.lift()
            pw.paneconfigure(self._ex_panel.win, **{"width" if horizontal else "height": ex})
            size = (bw + ex, max(bh, 640)) if horizontal else (max(bw, 480), bh + ex)
        if self._open("explorer") and self._open("assistant") and mode == "window":
            top = self._ex_top = tk.Toplevel(self.root)
            top.title("SK Assistant – Explorer")
            top.configure(bg=BG)
            top.geometry(self.cfg.explorer_geometry)
            top.minsize(360, 360)
            top.attributes("-topmost", bool(self.cfg.always_on_top))
            top.protocol("WM_DELETE_WINDOW", lambda: self.close_part("explorer"))
            top.after(200, lambda: hide_from_capture(top))
            self._ex_panel = ExplorerPanel(top, self.atlas, self.explorer, self._ui_font)
            self._ex_panel.win.pack(fill="both", expand=True)
        if vis != before or (mode, len(vis)) != getattr(self, "_last_mode", None):
            self.root.geometry(f"{size[0]}x{size[1]}")   # resize only when the content changed
        self._last_vis, self._last_mode = vis, (mode, len(vis))
        self._laid_out = True
        self._style_tabs()

    def _ui_font(self, size: int, bold: bool = False):
        return self._font(FONT_SEMI if bold else FONT, size)

    def _atlas_poll(self) -> None:
        """New rooms waiting for approval: a dot on the Explorer tab."""
        try:
            while True:
                self.atlas_q.get_nowait()
        except (queue.Empty, AttributeError):
            pass
        self._style_tabs()
        self.root.after(1500, self._atlas_poll)

    def restart_for_update(self) -> None:
        from . import updater
        updater.restart()
        self.close()

    def _check_updates_later(self) -> None:
        """Quietly look for a new version at start (never installs)."""
        self._update_found = None
        if not self.cfg.check_updates:
            return

        def work():
            from . import updater
            try:
                self._update_found = updater.check()
            except Exception:
                return
            if self._update_found is not None:
                v = self._update_found.version
                self.root.after(0, lambda: self.l_warn.config(
                    text=f"Update available: version {v} - Settings > Updates", fg=ACCENT))
        threading.Thread(target=work, daemon=True).start()

    def open_settings(self) -> None:
        self._settings = open_settings(
            self._settings, self.root, self.cfg, self.memory, self._setting_changed,
            {"region": self.pick_region, "auto": self.clear_region,
             "snapshot": self.engine.snapshot, "restart": self.restart_for_update,
             "update_found": lambda: self._update_found})

    def _setting_changed(self, name: str) -> None:
        if name == "assistant_on":
            self._update_power()
        elif name == "always_on_top":
            self.root.attributes("-topmost", bool(self.cfg.always_on_top))
            try:
                if self._ex_top is not None and self._ex_top.winfo_exists():
                    self._ex_top.attributes("-topmost", bool(self.cfg.always_on_top))
            except tk.TclError:
                pass
        elif name == "text_scale":
            self._apply_text_scale()
            self._rerender()
        elif name == "overlay":
            self._update_overlay_button()
            self._draw_overlay()
        elif name in ("weapon_puzzle", "money_puzzle", "questions"):
            self.engine.rescan()
        elif name == "memory" and self._view is None and self.cfg.assistant_on:
            self._waiting("Waiting for puzzle…")

    def _scale(self) -> float:
        return min(1.6, max(0.8, float(self.cfg.text_scale or 1.0)))

    def _font(self, family: str, size: int) -> tkfont.Font:
        """Shared named font for a base size. Changing the text size resizes
        these in place, so every label using one is redrawn at once."""
        key = (family, size)
        f = self._fonts.get(key)
        if f is None:
            f = self._fonts[key] = tkfont.Font(root=self.root, family=family,
                                               size=max(6, round(size * self._scale())))
        return f

    def _apply_text_scale(self) -> None:
        """Text size (Settings > General): resize every named font."""
        for (_family, size), f in self._fonts.items():
            f.configure(size=max(6, round(size * self._scale())))
        self._rerender()
        # bigger text needs more room: grow the window if the content no longer fits
        r = self.root
        r.update_idletasks()
        need, have = r.winfo_reqheight(), r.winfo_height()
        if have > 1 and need > have:
            r.geometry(f"{r.winfo_width()}x{need}")

    def toggle_overlay(self) -> None:
        self.cfg.overlay = not self.cfg.overlay
        self.cfg.save()
        self._update_overlay_button()
        self._draw_overlay()

    def _update_overlay_button(self) -> None:
        if self.b_overlay is not None:
            self.b_overlay.config(text="Numbers: on" if self.cfg.overlay else "Numbers: off")

    def _draw_overlay(self) -> None:
        p, a, money = self._last_place, self._last_analysis, self._last_money
        qn = getattr(self, "_last_question", None)
        if not self.cfg.overlay or p is None or (a is None and money is None and qn is None):
            self.overlay.clear()
            return
        if qn is not None:
            self.overlay.show(question_overlay_items(*qn, p,
                                                     progress=getattr(self, "_q_progress", 0)))
        elif money is not None:
            self.overlay.show(money_overlay_items(money, p))
        else:
            self.overlay.show(overlay_items(a, p["cards"]))

    def pick_region(self) -> None:
        self.engine.set_paused(True)
        self.overlay.clear()
        self.root.withdraw()

        def done(region):
            self.root.deiconify()
            self.root.attributes("-topmost", True)
            if region:
                self.cfg.region = region
                self.cfg.save()
                self.engine.region_changed.set()
            self._update_region_label()
            self.engine.set_paused(False)
            self.engine.rescan()

        self.root.after(150, lambda: RegionSelector(self.root, done))

    def clear_region(self) -> None:
        self.cfg.region = None
        self.cfg.save()
        self.engine.region_changed.set()
        self._update_region_label()
        self.engine.rescan()

    def _update_region_label(self) -> None:
        self.l_mode.config(text="region" if self.cfg.region else "read-only")

    def _on_resize(self, event) -> None:
        if event.widget is not self.main:
            return
        w = event.width
        if abs(w - self._last_w) < 4:
            return
        self._last_w = w
        for lbl in (self.l_next, self.l_hint, self.l_warn, self.l_main):
            lbl.config(wraplength=max(150, w - 60))
        if self._resize_job:
            self.root.after_cancel(self._resize_job)
        self._resize_job = self.root.after(60, self._rerender)

    def _rerender(self) -> None:
        self._resize_job = None
        if self._view and self._view.get("analysis") is not None:
            self._render(self._view["analysis"])
        elif self._view and self._view.get("money") is not None:
            self._render_money(self._view["money"])
        elif self._view and self._view.get("question") is not None:
            self._render_question(*self._view["question"])

    # -- engine messages -----------------------------------------------------
    def _poll(self) -> None:
        latest = None
        try:
            while True:
                latest = self.q.get_nowait()
                if latest.get("state") == "info":
                    self.l_hint.config(text=latest.get("msg", ""), fg=ACCENT)
                    latest = None
                elif latest.get("state") == "overlay_clear":
                    self._last_place = None
                    self.overlay.clear()
                    latest = None
        except queue.Empty:
            pass
        if latest:
            self._show(latest)
        self.root.after(25, self._poll)

    def _show(self, m: dict) -> None:
        if not self.cfg.assistant_on:
            return
        st = m.get("state")
        if st in ("waiting", "searching", "analyzing"):
            self._last_place = self._last_analysis = self._last_money = None
            self._last_question = None
            self.overlay.clear()
            if st == "waiting":
                self._waiting(m.get("msg", "Waiting for puzzle…"))
            else:
                self._pill("Reading…", R.BLUE)
            return
        if st == "error":
            self._pill("Error", R.RED)
            self.l_warn.config(text=m.get("msg", ""), fg=BAD)
            return
        if st == "question_wait":
            self._last_place = self._last_analysis = self._last_money = None
            self.overlay.clear()
            self._view = None
            self._pill("Question", R.BLUE)
            self.l_target.config(text="A question is on screen")
            self.l_section.config(text="")
            self._set_image(self.l_main, "main", None)
            self.l_main.config(text="Press Rescan (F5)", fg=FG, font=self._font(FONT_SEMI, 18))
            self.l_next.config(text="Questions are read only when you ask (Settings).", fg=DIM)
            self.l_hint.config(text="")
            return
        if st == "question_progress":
            if getattr(self, "_last_question", None) is not None:
                self._q_progress = int(m.get("progress", 0))
                self._draw_overlay()
            return
        if st == "question":
            self._last_analysis = self._last_money = None
            self._last_place = m.get("place")
            self._q_progress = int(m.get("progress", 0) or 0)
            self._last_question = (m.get("question"), m.get("answer"), m.get("status"))
            self._render_question(*self._last_question, extra=m)
            self._draw_overlay()
            return
        if st == "money":
            self._last_analysis, self._last_money = None, m.get("money")
            self._last_place = m.get("place")
            self._render_money(self._last_money)
            self._draw_overlay()
            return
        a: Optional[Analysis] = m.get("analysis")
        if a is None:
            return
        self._last_money = None
        self._render(a)
        self._last_analysis, self._last_place = a, m.get("place")
        self._draw_overlay()

    def _waiting(self, msg: str) -> None:
        self._view = None
        self._pill("Waiting", R.MUTED)
        self.l_target.config(text="Open a puzzle or a question in the game")
        self.l_section.config(text="")
        self._set_image(self.l_main, "main", None)
        self.l_main.config(text="Waiting for puzzle…" if "No puzzle" not in msg else msg,
                           fg=DIM, font=self._font(FONT_SEMI, 18))
        self.l_next.config(text="")
        self.l_tag_title.config(text="")
        self._set_image(self.l_tags, "tags", None)
        st = self.memory.stats()
        notes = ("\n" + "; ".join(self._startup_notes).capitalize() + ".") \
            if getattr(self, "_startup_notes", None) else ""
        self.l_hint.config(text="Weapon assembly, money counting and questions are detected "
                                f"automatically.\nMemory: {st['questions']} learned questions.{notes}",
                           fg=DIM)
        err = getattr(getattr(self, "overlay", None), "error", "")
        self.l_warn.config(text=f"Numbers on cards unavailable: {err}" if err else "", fg=WARN)

    def _render(self, a: Analysis) -> None:
        self._view = {"analysis": a}
        s, p = a.solution, a.puzzle
        width = self._content_width()
        if s is None or p is None:
            self._pill("No answer", R.RED)
            self.l_section.config(text="")
            self._set_image(self.l_main, "main", None)
            self.l_main.config(text="Can't read this puzzle", fg=BAD, font=self._font(FONT_SEMI, 16))
            self.l_next.config(text=a.error)
            self.l_hint.config(text="Press F5 to read again", fg=DIM)
            return
        target = p.target_caliber or "?"
        self.l_target.config(text=f"{p.weapon or 'Arma'}  ·  calibre {target}")
        dont = [(l, p.pieces[l].caliber or "") for l in s.excluded]

        if s.ok and s.certain:
            self._pill("Verified", R.GREEN_SOFT)
            self.l_warn.config(text="")
            if s.remaining:
                nums = dict(s.numbering) or {l: i + 1 for i, l in enumerate(s.order)}
                nxt = s.remaining[0]
                steps = [(l, nums.get(l, i + 1),
                          "done" if l in s.done else ("next" if l == nxt else "step"),
                          p.pieces[l].name) for i, l in enumerate(s.order)]
                self.l_section.config(text=f"ORDER  ·  {len(s.done)}/{len(s.order)} DONE"
                                      if s.done else "ORDER")
                self.l_main.config(text="")
                self._set_image(self.l_main, "main", R.chips(steps, width, R.SURFACE))
                name = p.pieces[nxt].name
                self.l_next.config(text=f"Next:  {nxt}" + (f"  ·  {name}" if name else ""), fg=FG)
                self.l_hint.config(text="Then press PROBAR. Pieces turn ✓ as you mount them.",
                                   fg=DIM)
            else:
                self.l_section.config(text="ALL PIECES MOUNTED")
                self.l_main.config(text="")
                self._set_image(self.l_main, "main", R.pill("PROBAR", 40))
                self.l_next.config(text="Press Probar to test the weapon.", fg=FG)
                self.l_hint.config(text="")
            self._tags(dont, width)
            return

        # Not verified: never show an order that looks clickable. A click on a
        # piece that is not ready costs a point.
        check = ", ".join(s.doubtful)
        self._set_image(self.l_main, "main", None)
        self._tags([], width)
        if s.ok:
            self._pill("Not sure", R.AMBER)
            self.l_section.config(text="DON'T FOLLOW YET")
            self.l_main.config(text=f"Check card {check}" if check else "Reading unclear",
                               fg=WARN, font=self._font(FONT_SEMI, 18))
            guess = " → ".join(s.remaining)
            self.l_next.config(text=f"Unverified guess:  {guess}" if guess else "", fg=DIM)
        else:
            self._pill("No answer", R.RED)
            self.l_section.config(text="NOT RELIABLE")
            self.l_main.config(text=f"Check card {check}" if check else "Can't solve this reading",
                               fg=BAD, font=self._font(FONT_SEMI, 18))
            self.l_next.config(text="")
        self.l_hint.config(text="Press F5 to read again.", fg=DIM)
        msgs = [f"✖  {x}" for x in s.problems] + [f"⚠  {x}" for x in s.warnings]
        self.l_warn.config(text="\n".join(msgs[:4]) + ("\n…" if len(msgs) > 4 else ""),
                           fg=BAD if s.problems else WARN)

    def _render_money(self, st) -> None:
        """'Cuenta el dinero': running total, then the verified total."""
        self._view = {"money": st}
        self._set_image(self.l_main, "main", None)
        self._tags([], 0)
        legend = "  ·  ".join(str(v) for v in st.legend)
        self.l_target.config(text="Cuenta el dinero" + (f"   ·   {legend}" if legend else ""))
        values = " + ".join(f"{v}" if sure else f"{v if v is not None else '?'}?"
                            for v, sure in st.items)
        seen = f"{st.counted}/{st.expected}" if st.expected else f"{st.counted}"
        if st.done and st.verified:
            self._pill("Verified", R.GREEN_SOFT)
            self.l_section.config(text=f"TOTAL  ·  {st.counted} ITEMS")
            self.l_main.config(text=f"{st.total}", fg=GOOD, font=self._font(FONT_SEMI, 34))
            self.l_hint.config(text="Type it in yourself, then press ✓.", fg=DIM)
            self.l_warn.config(text="")
        elif st.done:
            self._pill("Not sure", R.AMBER)
            self.l_section.config(text="DON'T TRUST YET")
            self.l_main.config(text=f"{st.total} ?", fg=WARN, font=self._font(FONT_SEMI, 30))
            self.l_hint.config(text="The count doesn't match the game. Check before typing.",
                               fg=DIM)
            self.l_warn.config(text="\n".join(f"⚠  {p}" for p in st.problems[:4]), fg=WARN)
        else:
            self._pill("Counting", R.BLUE)
            self.l_section.config(text=f"RUNNING TOTAL  ·  SEEN {seen}")
            self.l_main.config(text=f"{st.total}" if st.counted else "…", fg=FG,
                               font=self._font(FONT_SEMI, 30))
            self.l_hint.config(text="Wait until the strip is empty.", fg=DIM)
            self.l_warn.config(text="")
        self.l_next.config(text=values, fg=DIM if not st.done else FG)

    def _render_question(self, q, ans, status: str = "", extra: Optional[dict] = None) -> None:
        """A recognised question and its answer.
        status: 'memory' | 'solver' | 'game' | 'ai' | 'unsure' | 'thinking' |
                'unknown' (not learned yet) | 'answered' (result not readable)"""
        extra = extra or {}
        self._view = {"question": (q, ans, status, extra)}
        self._set_image(self.l_main, "main", None)
        self._tags([], 0)
        label = {"memory": ("From memory", R.GREEN_SOFT), "game": ("Learned ✓", R.GREEN_SOFT),
                 "solver": ("Solved", R.GREEN_SOFT), "ai": ("AI · unverified", R.AMBER),
                 "likely": ("Probably", R.AMBER),
                 "unsure": ("Not sure", R.AMBER), "thinking": ("Thinking…", R.BLUE),
                 "unknown": ("New question", R.AMBER), "answered": ("Answered", R.MUTED)}
        text, colour = label.get(status, ("Question", R.BLUE))
        self._pill(text, colour)
        self.l_target.config(text=(q.category or "Pregunta").upper())
        self.l_section.config(text="CORRECT ANSWER" if status == "game" else "ANSWER")
        if ans is None:
            msg = {"unknown": "Not learned yet", "answered": "Result not readable",
                   "thinking": "Asking the AI…"}.get(status, "…")
            self.l_main.config(text=msg, fg=WARN if status == "unknown" else DIM,
                               font=self._font(FONT_SEMI, 16))
            self.l_next.config(text=q.text + (("\n" + "  ·  ".join(q.clues)) if q.clues else ""),
                               fg=FG)
            hint = ""
            if status == "unknown":
                hint = ("Answer it in the game: SK Assistant remembers the correct "
                        "answer for next time.")
                if extra.get("ai_note"):
                    hint += f"\nAI: {extra['ai_note']}."
            self.l_hint.config(text=hint, fg=DIM)
            self.l_warn.config(text="")
            return
        else:
            shown = extra.get("display") or ans          # clean learned text when available
            size = 16
            if ans.kind == "choice" and ans.choice in q.options:
                letter = "ABCDEFGH"[q.options.index(ans.choice)]
                main = f"{letter}.  {shown.choice or ans.choice}"
            elif ans.kind == "pairs":
                main = "\n".join(f"{a}  →  {b}" for a, b in (shown.pairs or ans.pairs).items())
                size = 13
            elif ans.kind == "order":
                main = "\n".join(f"{i}.  {x}" for i, x in enumerate(shown.order or ans.order, 1))
                size = 13
            else:
                main = ans.summary()
            sure = status in ("memory", "game", "solver", "ai")
            self.l_main.config(text=main, fg=GOOD if sure else WARN, font=self._font(FONT_SEMI, size))
        clues = ("\n" + "  ·  ".join(q.clues)) if q.clues else ""
        self.l_next.config(text=q.text + clues, fg=FG)
        expl = ans.explanation if ans and ans.explanation else ""
        if status == "likely":
            expl = ("Check before clicking: " + expl) if expl else "Check before clicking."
        elif status == "ai":
            expl = "The AI thinks so; it can be wrong. " + expl
        elif status == "unsure":
            expl = "The AI is NOT sure: only a guess. " + expl
        if status in ("ai", "unsure") and extra.get("ai_info"):
            expl += f"\n({extra['ai_info']})"
        self.l_hint.config(text=expl.strip(), fg=WARN if status in ("likely", "ai", "unsure")
                           else DIM)
        self.l_warn.config(text="")

    def _tags(self, items, width: int) -> None:
        img = R.tags(items, 22, R.RED, R.SURFACE) if items else None
        self.l_tag_title.config(text="Don't click" if items else "")
        self._set_image(self.l_tags, "tags", img)

    # -- lifecycle -------------------------------------------------------------
    def run(self) -> None:
        self.engine.start()
        self._layout()
        if self.explorer is not None:
            self.explorer.start()
            self.root.after(1500, self._atlas_poll)
        self.root.after(25, self._poll)
        self.root.after(4000, self._check_updates_later)
        self.root.mainloop()

    def close(self) -> None:
        try:
            self._save_explorer_geometry()
            self.cfg.window_geometry = self._base_geom
            self.cfg.save()
        finally:
            self.engine.stop()
            if self.explorer is not None:
                self.explorer.stop()
            self.memory.close()
            self.root.destroy()


def _flat_button(parent, text: str, cmd, font) -> tk.Label:
    """Flat, rounded-looking text button with hover highlight."""
    b = tk.Label(parent, text=text, bg=PANEL, fg=DIM, font=font, padx=10, pady=4,
                 cursor="hand2")
    b.bind("<Button-1>", lambda e: cmd())
    b.bind("<Enter>", lambda e: b.config(bg=HOVER, fg=FG))
    b.bind("<Leave>", lambda e: b.config(bg=PANEL, fg=DIM))
    return b


def _app_icon(size: int):
    import os
    from PIL import Image
    path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "assets", "app.png")
    try:
        return Image.open(path).convert("RGBA").resize((size, size), Image.LANCZOS)
    except Exception:
        return None
